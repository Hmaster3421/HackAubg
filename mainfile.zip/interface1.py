import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel, QVBoxLayout, QWidget
from PySide6.QtGui import QIcon
from PySide6.QtCore import Qt, QSize, QTimer
from threading import Thread
import speech_recognition as sr
import pyttsx3


class VoiceAssistant(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Voice Assistant")
        self.setStyleSheet("background-color: white; color: black;")
        self.showMaximized()

        self.central_widget = QWidget(self)
        self.setCentralWidget(self.central_widget)

        self.layout = QVBoxLayout(self.central_widget)
        self.layout.setAlignment(Qt.AlignCenter)

        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.show_main_window)
        self.timer.start(3000)

        # Initialize the text-to-speech engine
        self.tts_engine = pyttsx3.init()

    def show_main_window(self):
        self.setStyleSheet("background-color: black; color: white;")

        self.ready_label = QLabel("Ready to help!", self)
        font = self.ready_label.font()
        font.setPointSize(24)
        font.setBold(True)
        self.ready_label.setFont(font)
        self.ready_label.setAlignment(Qt.AlignHCenter | Qt.AlignTop)
        self.layout.addWidget(self.ready_label, alignment=Qt.AlignTop)

        self.start_button = QPushButton("Start", self)
        self.start_button.clicked.connect(self.start_listening)
        self.layout.addWidget(self.start_button)

        self.stop_button = QPushButton("Stop", self)
        self.stop_button.clicked.connect(self.stop_listening)
        self.stop_button.setEnabled(False)
        self.stop_button.hide()
        self.layout.addWidget(self.stop_button, alignment=Qt.AlignCenter)

        self.pause_button = QPushButton("Pause", self)
        self.pause_button.clicked.connect(self.pause_listening)
        self.pause_button.hide()
        self.layout.addWidget(self.pause_button, alignment=Qt.AlignCenter)

        self.exit_button = QPushButton("Exit", self)
        self.exit_button.clicked.connect(self.exit_program)
        self.exit_button.setEnabled(False)
        self.layout.addWidget(self.exit_button, alignment=Qt.AlignCenter)

        self.helping_label = QLabel("", self)
        font = self.helping_label.font()
        font.setPointSize(24)
        font.setBold(True)
        self.helping_label.setFont(font)
        self.helping_label.setAlignment(Qt.AlignHCenter | Qt.AlignTop)
        self.layout.addWidget(self.helping_label, alignment=Qt.AlignTop)

        self.recognizer = sr.Recognizer()
        self.stop_listening_flag = False

    def start_listening(self):
        self.start_button.hide()
        self.pause_button.show()
        self.ready_label.setText("Helping...")
        self.ready_label.show()
        self.stop_button.show()
        self.stop_button.setEnabled(True)
        self.exit_button.setEnabled(False)
        self.stop_listening_flag = False
        listen_thread = Thread(target=self.listen_thread)
        listen_thread.start()

    def pause_listening(self):
        if self.pause_button.text() == "Pause":
            self.pause_button.setText("Unpause")
            self.start_button.setText("Start Again")
            self.stop_button.setText("Start Again")
            self.ready_label.setText("Paused...")
            self.exit_button.setEnabled(True)
            self.stop_listening_flag = True
        else:
            self.pause_button.setText("Pause")
            self.start_button.setText("Start")
            self.stop_button.setText("Stop")
            self.ready_label.setText("Resuming...")
            self.exit_button.setEnabled(False)
            self.stop_listening_flag = False
            listen_thread = Thread(target=self.listen_thread)
            listen_thread.start()

    def stop_listening(self):
        self.stop_listening_flag = True
        self.start_button.show()
        self.pause_button.hide()
        self.ready_label.setText("Ready to help!")
        self.ready_label.show()
        self.stop_button.hide()
        self.stop_button.setEnabled(False)
        self.exit_button.setEnabled(True)
        self.helping_label.hide()

    def reset_ui(self):
        # Reset UI to the main window state
        self.start_button.show()
        self.start_button.setText("Start")
        self.pause_button.hide()
        self.ready_label.setText("Ready to help!")
        self.ready_label.show()
        self.stop_button.hide()
        self.stop_button.setEnabled(False)
        self.exit_button.setEnabled(False)
        self.helping_label.hide()

    def listen_thread(self):
        while not self.stop_listening_flag:
            with sr.Microphone() as source:
                self.recognizer.adjust_for_ambient_noise(source)
                print("Listening...")
                audio = self.recognizer.listen(source)
                print("Recognizing...")
                try:
                    text = self.recognizer.recognize_google(audio)
                    print("You said:", text)
                    self.process_command(text)
                except sr.UnknownValueError:
                    print("Sorry, I couldn't understand what you said.")
                except sr.RequestError as e:
                    print("Error:", e)

    def process_command(self, text):
        if "hello" in text.lower():
            self.helping_label.setText("Hello .  I'm  your  medical  AI  assistant  TESS .  How can I help?")
            self.helping_label.show()
            self.say_text("Hello .  I'm  your  medical  AI  assistant  TESS .  How can I help?")
        elif "thank you goodbye" in text.lower():
            self.helping_label.setText("Happy to help. See you soon!")
            self.helping_label.show()
            self.say_text("Happy to help. See you soon!")
            self.reset_ui()
        elif "Show me images of broken left or right arm" in text.lower():
            self.helping_label.setText("")
            self.helping_label.show()
            self.say_text("Opening Google...")
        else:
            self.helping_label.setText("Sorry, I didn't recognize that question.")
            self.helping_label.show()
            self.say_text("Sorry, I didn't recognize that question.")

    def say_text(self, text):
        self.tts_engine.say(text)
        self.tts_engine.runAndWait()

    def exit_program(self):
        sys.exit()

    def sizeHint(self):
        return QSize(300, 200)

    def closeEvent(self, event):
        self.stop_listening()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = VoiceAssistant()
    window.show()
    sys.exit(app.exec())
